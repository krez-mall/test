<?php

file_get_contents('http://spd.gavadinov.com/crawl');
